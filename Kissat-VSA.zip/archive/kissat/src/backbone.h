#ifndef _backbone_h_INCLUDED
#define _backbone_h_INCLUDED

#include <stdbool.h>

struct kissat;
void kissat_binary_clauses_backbone (struct kissat *);

#endif
