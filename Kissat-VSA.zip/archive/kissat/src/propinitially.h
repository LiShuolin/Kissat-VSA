#ifndef _propinitially_h_INCLUDED
#define _propinitially_h_INCLUDED

#include <stdbool.h>

struct kissat;

bool kissat_initially_propagate (struct kissat *);

#endif
