#!/bin/sh
exec ./kissat $1 $2/proof.out
