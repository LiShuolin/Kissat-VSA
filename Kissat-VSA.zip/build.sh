#!/bin/sh

cd archive/kissat
./configure --competition --test
make all || exit 1
build/tissat || exit 1
exec install -s build/kissat ../..
